-- Example: Using a Java UDF in Impala
CREATE FUNCTION date_format
  LOCATION 'hdfs:/myscripts/date-format-udf.jar'
  SYMBOL='com.nexr.platform.hive.udf.UDFDateFormat';

SELECT date_format(CAST(order_date AS STRING), 'dd-MMM-yyyy')
  FROM orders LIMIT 1;


-- Example: Using a C++ UDF in Impala
CREATE FUNCTION count_vowels(STRING) 
  RETURNS INT 
  LOCATION '/user/hive/udfs/sampleudfs.so'
  SYMBOL='CountVowels';

SELECT count_vowels(email_address) FROM employees;    


-- Example: Impala Variables
SET var:mystate=CA;

SELECT * FROM customers
  WHERE state = '${var:mystate}';
