-- Example: Creating a Database
CREATE DATABASE dualcore; 
CREATE DATABASE IF NOT EXISTS dualcore;


-- Example: Creating a Table
CREATE TABLE jobs (
    id INT, 
    title STRING, 
    salary INT, 
    posted TIMESTAMP
  )
  ROW FORMAT DELIMITED 
    FIELDS TERMINATED BY ','
  LOCATION '/dualcore/jobs';


-- Example: Creating Tables Based On Existing Schema
CREATE TABLE jobs_archived LIKE jobs;


-- Example: Creating an Externally Managed Table
CREATE EXTERNAL TABLE adclicks (
    campaign_id STRING,
    click_time TIMESTAMP,
    keyword STRING, 
    site STRING,
    placement STRING,
    was_clicked BOOLEAN,
    cost SMALLINT
  )
  LOCATION '/dualcore/ad_data';


-- Example: Loading Data From HDFS Files
-- (sales.txt must be in user's home HDFS directory)
LOAD DATA INPATH 'sales.txt' INTO TABLE sales;


-- Example: Overwriting Data from Files
LOAD DATA INPATH 'sales.txt' OVERWRITE INTO TABLE sales;


-- Example: Removing a Table
DROP TABLE customers;
DROP TABLE IF EXISTS customers;


-- Example: Removing a Database
DROP DATABASE dualcore;
DROP DATABASE IF EXISTS dualcore;
DROP DATABASE dualcore CASCADE;


-- Example: Renaming and Modifying Columns
ALTER TABLE clients CHANGE fname first_name STRING;
ALTER TABLE jobs CHANGE salary salary BIGINT;


-- Example: Reordering Columns in Hive
-- (Hive only)
ALTER TABLE jobs CHANGE salary salary INT AFTER id;
ALTER TABLE jobs CHANGE salary salary INT FIRST;


-- Example: Adding Columns
ALTER TABLE jobs ADD COLUMNS (city STRING, bonus INT);


-- Example: Removing Columns in Impala
-- (Impala only)
ALTER TABLE jobs DROP COLUMN salary;


-- Example: Replacing Columns and Reproducing Tables
ALTER TABLE jobs REPLACE COLUMNS (
   id INT,
   title STRING,
   salary INT
);
SHOW CREATE TABLE jobs;


-- Example: Creating Views
CREATE VIEW order_info AS
  SELECT o.order_id, order_date, p.prod_id, brand, name
  FROM orders o 
  JOIN order_details d 
  ON (o.order_id = d.order_id)
  JOIN products p
  ON (d.prod_id = p.prod_id);


-- Example: Exploring Views
SHOW TABLES;
DESCRIBE FORMATTED order_info;
SHOW CREATE TABLE order_info;


-- Example: Modifying and Removing Views
ALTER VIEW order_info AS
  SELECT order_id, order_date FROM orders;

ALTER VIEW order_info RENAME TO order_information;

DROP VIEW order_info;


-- Example: Saving Query Output to a Table
CREATE TABLE nyc_customers LIKE customers;

INSERT OVERWRITE TABLE nyc_customers 
  SELECT * FROM customers 
  WHERE state = 'NY' AND city = 'New York';

INSERT INTO TABLE nyc_customers 
  SELECT * FROM customers 
  WHERE state = 'NY' AND city = 'Brooklyn';


-- Example: Creating Tables Based On Existing Data
CREATE TABLE ny_customers 
  ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'
  STORED AS TEXTFILE
AS
  SELECT cust_id, fname, lname 
  FROM customers
  WHERE state = 'NY';


-- Example: Writing Output to HDFS in Hive
-- (Hive only)
INSERT OVERWRITE DIRECTORY '/dualcore/ny/'
  ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' 
    SELECT * FROM customers
    WHERE state = 'NY';


-- Example: Saving to Multiple Directories in Hive
-- (Hive only)
INSERT OVERWRITE DIRECTORY 'ny_customers'
  SELECT cust_id, fname, lname
    FROM customers WHERE state = 'NY';

FROM customers c
  INSERT OVERWRITE DIRECTORY 'ny_customers'
    SELECT cust_id, fname, lname WHERE state='NY';

FROM customers c 
  INSERT OVERWRITE DIRECTORY 'ny_names'
    SELECT fname, lname 
      WHERE state = 'NY'
  INSERT OVERWRITE DIRECTORY 'ny_count'
    SELECT count(DISTINCT cust_id) 
      WHERE state = 'NY';

FROM (SELECT * FROM customers WHERE state='NY') nycust 
  INSERT OVERWRITE DIRECTORY 'ny_names'
    SELECT fname, lname
  INSERT OVERWRITE DIRECTORY 'ny_count'
    SELECT count(DISTINCT cust_id);
