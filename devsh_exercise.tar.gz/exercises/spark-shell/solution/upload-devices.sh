#!/bin/sh

hdfs dfs -put $DEVDATA/devices.json /loudacre/