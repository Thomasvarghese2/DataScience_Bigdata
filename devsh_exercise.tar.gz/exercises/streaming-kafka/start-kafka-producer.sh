$DEVSH/scripts/streamtest-kafka.sh weblogs worker-1:9092 20 $DEVDATA/weblogs/*
